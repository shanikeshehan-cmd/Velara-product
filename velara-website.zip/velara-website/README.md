# Velará Products Website

Static website for Velará Products (herbal cosmetics) – managed by Icon Marketers (Pvt) Ltd.

## Publish on GitHub Pages
1. Create a new repository on GitHub (e.g. `velara-products`).
2. Upload ALL files and folders from this project (index.html, css/, js/, images/).
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then **Save**.
5. Your site will be live at `https://YOUR-USERNAME.github.io/velara-products/` in a minute or two.

## Edit
- Text/products: `index.html`
- Colours: variables at top of `css/style.css`
- Images: `images/`
