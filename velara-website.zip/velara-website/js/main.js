document.getElementById('yr').textContent = new Date().getFullYear();
document.querySelectorAll('.links a').forEach(a => a.addEventListener('click', () => document.querySelector('.links').classList.remove('open')));
